clear

lib=./lib
classpath=HKEPrivateServer.jar
EXEC_CLASS=cfca.hke.privatization.server.app.startup.ServerBootstrap

for file in ${lib}/*.jar;
    do classpath=${classpath}:$file;
done

export LD_LIBRARY_PATH=/usr/cfca/lib
nohup java -server -XX:+HeapDumpOnOutOfMemoryError -XX:+StartAttachListener -Xms2048M -Xmx4096M -classpath ${classpath} $EXEC_CLASS ./HKEPrivateConfig &
