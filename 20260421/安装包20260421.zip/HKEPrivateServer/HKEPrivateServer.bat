@echo off
setlocal enabledelayedexpansion

set LIB=.\lib
set EXEC_CLASS=cfca.hke.privatization.server.app.startup.ServerBootstrap

:: 使用通配符，避免构建超长CLASSPATH
java -server ^
     -XX:+UseG1GC ^
     -XX:+HeapDumpOnOutOfMemoryError ^
     -XX:+StartAttachListener ^
     -Xms2048M ^
     -Xmx4096M ^
     -cp "HKEPrivateServer.jar;.\lib\*" ^
     %EXEC_CLASS% .\HKEPrivateConfig

endlocal
