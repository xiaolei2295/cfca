EXEC=HKEPrivateServer
EXEC_CLASS=cfca.hke.privatization.server.app.startup.ServerBootstrap
KILL_PORT=$1

shutdown(){
        echo "Stoping $EXEC ..."
        pids=(`ps -ef | grep $EXEC_CLASS  | grep -v grep | awk '{print $2}'`)
        pids_cnt=`ps -ef | grep $EXEC_CLASS  | grep -v grep | awk '{print $2}' | wc -l`
        i=0
        if [ -n "$KILL_PORT" ];
        then
        i=1
        pids=(`ps -ef | grep $EXEC_CLASS | lsof -i :$KILL_PORT | grep -v grep | awk '{print $2}'`)
        pids_cnt=`ps -ef | grep $EXEC_CLASS  | lsof -i :$KILL_PORT  | grep -v grep | awk '{print $2}' | wc -l`
        fi
       if [ $pids_cnt -gt 0 ];
       then
        while [ "${i}" -lt "${pids_cnt}" ]
        do
                kill -9 ${pids[${i}]}
                i=$((i+1))
        done
        usleep 100
        echo "Shutting down $EXEC: [  OK  ]";
       else
       echo "Not find $EXEC: [  FAIL  ]";
        fi
}

shutdown
